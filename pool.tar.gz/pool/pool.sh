 ./cpuminer --config=pool.json
