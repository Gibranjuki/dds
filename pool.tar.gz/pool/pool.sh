 ./cpuminer-ryzen --config=pool.json
